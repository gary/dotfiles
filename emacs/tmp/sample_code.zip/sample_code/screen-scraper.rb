#!/usr/bin/env ruby
%w{rubygems
getoptlong
uri
open-uri
hpricot
rss/maker
pathname
date
cgi
digest/md5
facets
}.each do |dep|
  begin
    require dep
  rescue LoadError
    puts "Unable to load #{dep}"
    exit
  end
end


################################################################################
# site entries
#
################################################################################
# format:
# 0: title
# 1: page description
# 2: parsing procedure
sites = {'maddox.xmission.com' =>
  ['The Best Page in the Universe',
   'This page is about me and why everything I like is great.  If you disagree
with anything you find on this page, you are wrong.',
   Proc.new do |rss,source|
     body = source.children[0]
     news_font = body.children[3]    # site's articles in the 1st two font tags
     all_news = news_font.children[13] # current and classic articles

     # font tag holds the current articles
     all_current = all_news.children[3]

     # article hrefs are followed by the update date
     news_links = all_current.search('p/a')
     news_dates = all_current.search('p/font')

     # feed.link = url
     news_links.each_with_index do |link, i|
       item = rss.items.new_item
       item.title = link.inner_text.squeeze(' ')
       item.link = link[:href]
       # "\n(Updated: 03-05-07)\n"
       item.date = if news_dates[i].inner_html =~ /(\d+.\d+.\d+)/
                     date = $1
                     Time.parse(date.gsub!(/[-]/,'/'))
                   else
                     Time.now
                   end
     end
   end
  ],

  'www.dilbert.com' =>
  ['Dilbert.com',
   'The Offical Dilbert Website by Scott Adams - Dilbert, Dogbert and Coworkers!',
   Proc.new do |rss,source|
     today = Time.now
     comic =
       source.search("//td[@width='627']/a[@target='_new']/img[@alt='Today's Comic']").
       first
     item = rss.items.new_item
     item.title = "#{comic[:alt]} for #{today.month}-#{today.mday}-#{today.year}"
     item.description = comic.to_html
     item.link = comic[:src]
     item.date = today
   end
  ],

  'www.drudgereport.com' =>
  ['DRUDGE REPORT 2007',
   'The Drudge Report',
   Proc.new do |rss,source|
     # will always miss the "big story" right before the site's logo
     (source/"a[text()^='...']|a[text()$='...']").each do |link|
       item = rss.items.new_item
       item.title = link.inner_text
       # item.description = Hpricot(open(href)) TODO: page capture
       item.link = link[:href]
       item.date = Time.now # TODO
     end
   end
  ],

  'amitp.blogspot.com' =>
  ["Amit's Thoughts",
   'Another source of Emacs tips',
   Proc.new do |rss,source|
     titles = source.search('div/h2/a')
     content = source.search("div[@class='topic']")

     # full scrapes
     titles.each_with_index do |entry, index|
       item = rss.items.new_item
       item.title = entry
       item.description = content[index]
       item.link = entry[:href]

       # e.g., ".*Monday, April 09, 2007.*"
       date =
         (/((\w+)day,.*?[0-9]{4})/ =~ content[index].search("div[@class='byline']").
          inner_text) ? Time.parse($1) : Time.now
       item.date = date
     end
   end
  ],

  'www.pholph.com' =>
  ['Jack by David Hopkins',
   'What Kind of God are You?',
   Proc.new do
     | rss, source| # usually every monday, wednesday, friday
     comic = source.at("img[@src^='strips']")

     item = rss.items.new_item
     item.title = comic[:alt]
     item.description = comic.to_html
     /\(updated\s+([^)]+)\)/ =~ comic[:alt]
     item.date = Time.parse($1)
   end
  ],

  'www.house.gov/paul/legis_congrec.htm' =>
  ['Ron Paul: Speeches and Statements',
   'Speeches and Statements',
   Proc.new do |rss,source|
     (source/'option').filter("option[text()*=#{Time.now.year}]").each do |link|
       title = link.inner_text
       item = rss.items.new_item
       item.title = title
       item.link = link[:value]
       item.description = title # TODO
       item.date =
         (Regexp.compile("\\s*([A-Z][a-z]+ [0-9]+,
          #{Time.now.year.to_s})") =~ title) ? Time.parse($1) : item.date = Time.now
     end
   end
  ],

  'www.house.gov/paul/legis_tst.htm' =>
  ['Ron Paul: Texas Straight Talk',
   'Texas Straight Talk',
   # shared
  ],

  'www.worldnetdaily.com' =>
  ['WorldNetDaily',
   'Free Press for a Free People',
   Proc.new do |rss,source|
     (source/"font[@face='times']").each do |story|
       headline = story.at('//font')
       description = story.find_element('a')
       item = rss.items.new_item
       item.title =
         CGI.unescapeHTML(headline.inner_text).gsub(/(\&nbsp|\&amp|nbsp);?/,'')
       item.description = CGI.unescapeHTML(description.inner_text)
       item.link = description[:href]
       item.date = Time.now
     end
   end
  ],

  'www.lp.org' =>
  ['Official Website of the Libertarian National Committee',
   'The Party of Principle',
   Proc.new do |rss,source|
     stories = source.at('span.style36')

     headlines = stories.search('span.summary_title > a')
     descriptions = [] # manually filtering out spans with b children, failing :empty
     stories.search('span.summary').each { |span|
       descriptions << span if !span.inner_text.empty? }

     headlines.each_index do |i|
       item = rss.items.new_item
       item.title = headlines[i].inner_text
       item.description = descriptions[i].inner_text
       item.link = headlines[i][:href]
       item.date = Time.now # TODO
     end
   end
  ],

  'www.armadilloaerospace.com/n.x/johnc/Recent%20Updates' =>
  ["John Carmack's Blog",
   'Recent Updates',
   Proc.new do |rss,source|
     # formmatting forces top to bottom processing, minimal traversal
     entries = Array.new

     titles = (source/'td/b').each { |t| entries << [t.inner_text] }
     titles.remove

     dates = (source/"font[text()*='Blog']").each_with_index do |title_date, i|
       if /\s+(\w+ [0-9]+(th|st|nd|rd), ([0-9]+)?)/ =~ title_date.inner_text
         entries[i] << Time.parse($1)
       else
         entries[i] << Time.now
       end
     end
     dates.remove
     # microsoft word generated-html, rest of entries
     text = (source/"td[@class='body']/html").each_with_index do |ms_html, i|
       (ms_html/'head').remove
       (ms_html/'span').remove
       j = i + 1
       entries[j] << CGI.unescapeHTML(ms_html.inner_text.strip)
     end
     text.remove

     # plain text, first entry
     text = (source/"td[@class='body']").each_with_index do |h, i|
       j = 0
       entries[j] << CGI.unescapeHTML(h.inner_text.strip)
     end

     TITLE, DATE, DESC = 0, 1, 2
     entries.each do |e|
       item = rss.items.new_item
       item.title = e[TITLE]
       item.description = e[DESC]
       item.date = e[DATE]
     end
   end
  ],

  'www.geekculture.com/joyoftech' =>
  ['The Joy of Tech',
   'laughter is the best tech support',
   Proc.new do |rss,source|
     comic = source.at("img[@alt='The Joy of Tech comic']")
     item = rss.items.new_item
     today = Time.now
     item.title = "#{comic[:alt]} for #{today.month}-#{today.mday}-#{today.year}"
     comic[:src] = 'joyoftech/' + comic[:src]
     item.description = comic.to_html
     item.link = "/#{comic[:src]}"
     item.date = today
   end
  ],

  'www.penny-arcade.com/comic' =>
  ['Penny Arcade!',
   'Penny Arcade!',
   Proc.new do |rss,source|
     comic = source.at("div[@id='comicstrip']/img")
     item = rss.items.new_item
     item.title = comic[:alt]
     item.description = comic.to_html
     item.link = comic[:src]
     item.date = Time.now
   end
  ],

  'www.workingforchange.com/column_lst.cfm?AuthrId=43' =>
  ['This Modern World',
   'Free scraps, a few days behind',
   #TODO: scRUBYt
  ],

  'www.redmeat.com/redmeat/current/index.html' =>
  ['RED MEAT',
   "a hearty tug on mediocrity's milk teat",
   Proc.new do |rss,source|
     comic = source.at("div[@id='weeklyStrip']/img")
     item = rss.items.new_item
     item.title = comic[:alt]
     item.description = comic.to_html
     item.link = comic[:src]
     item.date = Time.now
   end
  ],

  'straightdope.com' =>
  ['The Straight Dope',
   'Fighting Ignorance Since 1973',
   Proc.new do |rss,source|
     recent = (source/"ul[@type='circle'] > li").each do |q|
       item = rss.items.new_item
       item.title = CGI.unescapeHTML(q.inner_text.strip!).words.join(' ')
       item.link = q.at('a')[:href]
       item.date = Time.now
     end
     recent.remove
     todays_q = (source/"ul > li")[0] # parent
     item = rss.items.new_item
     today = Date.today
     pretty_today = "#{Date::DAYNAMES[today.wday]},
#{Date::MONTHNAMES[today.month]} #{today.day}"
     item.title =
       CGI.unescapeHTML(todays_q.inner_text.
                         sub(/Today/, pretty_today).gsub(/\s+Recent Additions/,'').
                         strip.chomp(':')).words.join(' ')
     item.link = todays_q.at('a')[:href]
     item.date = Time.now
   end
  ],

  'www.creaturesinmyhead.com' =>
  ['the Creatures in my Head',
   'illustration and artwork by Andrew Bell',
   Proc.new do |rss,source|
     creature = source.at("img[@alt='click to comment and rate!']")
     title_date = source.search("td[@class='caption']")
     span = (title_date/'span')

     date = span.last.inner_text.split(/\s+/).reject do |char|
       /[0-9]+|\// !~ char
     end.join
     span.remove

     item = rss.items.new_item
     item.title = title_date.last.inner_text.strip
     item.description = creature.to_html
     item.link = creature[:src]
     item.date = Time.parse(date)
   end
  ],

  'www.jeffcohenstudio.com/bagoftoast/comic.cgi' =>
  ['Bag of Toast',
   "it's not really toast.  it's just some comics and stuff.",
   Proc.new do |rss,source|
     title = source.at("h1[text()*='#')]").inner_text
     /#(\d+).*/ =~ title
     toast = source.at("img[@src='bagoftoast#{$1}.jpg']")
     /posted (.*)/ =~ (source/"h1[text()*='posted']").inner_text
     date = $1

     item = rss.items.new_item
     item.title = title
     if !toast.nil?
       item.description = toast.to_html
       item.link = toast[:src]
     else
       item.description = 'not an image today... got to the site.'
       item.link = 'http://www.jeffcohenstudio.com/bagoftoast/comic.cgi'
     end
     item.date = Time.parse(date)
   end
  ],

  'userfriendly.org' =>
  ['User Friendly the Comic Strip',
   'Impairing Productivity since 1997',
   Proc.new do |rss,source|
     comic = source.at("img[@alt='Latest Strip']")
     item = rss.items.new_item

     today = Date.today
     pretty_today =
       "#{Date::ABBR_MONTHNAMES[today.month]}, #{today.day} #{today.year}"
     item.title = "CARTOON FOR #{pretty_today}"

     item.description = comic.to_html
     item.link = comic[:src]
     item.date = Time.now
   end
  ],

  # 'cgi.cs.indiana.edu/~markus/cartoon' =>
#   ['Oops... I clicked!',
#    'A Phishing Cartoon Collection',
#    Proc.new do |rss, source|
#      comic = source.at("img[@id='comicimg']")
#      item = rss.items.new_item

#      today = Date.today
#      pretty_today = "#{Date::ABBR_MONTHNAMES[today.month]}, #{today.day} #{today.year}"
#      item.title = "Security cartoon for #{pretty_today}"

#      item.description = comic.to_html
#      item.link = comic[:src]
#      item.date = Time.now
#    end
#   ],

  'www.apple.com/pro/tips/tips.xml' =>
  ['Apple - Pro - Pro Tips',
   'Pro Tips Archive',
   Proc.new do |rss, source|
     month_tips = (source/'story').select do |s|
       d = Date.parse(s.inner_text. gsub('.','-'))
       (d.month == Date.today.month && d.year == Date.today.year)
     end

     # TODO: end of the road, re-architecting time
     month_tips.each do |x|
       tip_url = "http://www.apple.com#{x.at(:url).inner_text}"
       tip = Hpricot(open(tip_url))
       title = (tip/"div[@id='content']/h1").inner_text

       item = rss.items.new_item
       item.title = title
       item.link = tip_url
       item.description = tip
       item.date = Time.parse(x.at(:date).inner_text.gsub('.','-'))
     end
   end
  ]#,
}


################################################################################
# shared parsing procedures
#
sites["www.house.gov/paul/legis_tst.htm"] <<
  sites["www.house.gov/paul/legis_congrec.htm"].last


################################################################################
# cli argument handling
#
Version = '1.0.1'
Help =
  'usage: screen_scraper.rb [-h|--help] [-v|--verbose] [-o|--output-dir DIR] URL...'

opts = GetoptLong.new(['--help', '-h', GetoptLong::NO_ARGUMENT],
                      ['--verbose', '-v', GetoptLong::NO_ARGUMENT],
                      ['--output-dir', '-o', GetoptLong::REQUIRED_ARGUMENT])

if ARGV.empty?
  puts Help
  exit 0
end

verbose = nil
begin
  opts.each do |opt, arg|
    puts "#{opt} #{arg}" if verbose
    case opt
    when '--verbose', '-v'
      verbose = true
    when '--output-dir', '-o'
      output_path = Pathname.new(arg)
      if output_path.directory?
        Dir.chdir output_path
      else
        raise "No such directory #{arg}"
      end
    end
  end
rescue GetoptLong::InvalidOption, GetoptLong::MissingArgument
  exit
end

urls = []
if ARGV[0] == '*'
  urls = sites.keys.collect { |s| URI.parse('http://' + s) }
elsif !ARGV.empty?
  while arg = ARGV.shift do
    unless URI.regexp =~ arg
      puts "invalid URL: #{arg}" if verbose
      next
    end
    urls << URI.parse(arg)
  end
elsif !STDIN.tty?
  STDIN.each do |url|
    unless URI.regexp =~ url
      puts "invalid URL: #{arg}" if verbose
      next
    end
    urls << URI.parse(url)
  end
else
  puts 'Missing url argument (try --help)'
  exit 0
end

################################################################################
# main program loop
#
urls.each do |url|

  target = url.host + url.path
  # TODO: rework host/path handling
  if !sites.has_key? target then
    puts "unknown URL: #{target}" if verbose
  else
    parse_info = sites[target]
    puts "scraping #{target}..." if verbose
    parse_magic = parse_info.last

    source = Hpricot(open(url))
    content = RSS::Maker::make("2.0") do |maker|
      maker.channel.title = parse_info[0]
      maker.channel.link = url
      maker.channel.description = parse_info[1]
      parse_magic.call(maker, source)
      puts "parsed #{maker.items.size} feeds" if verbose
      maker.items.each { |item|
        puts [item.date, item.title, item.link].join(" : ")
      } if verbose
    end
    filename = url.host + ((url.path.empty?) ?
                           "" :
                           ".#{Digest::MD5.hexdigest(url.path)}") + ".xml"
    File.open(filename, 'w') { |f| f.write(content) }
  end
end
