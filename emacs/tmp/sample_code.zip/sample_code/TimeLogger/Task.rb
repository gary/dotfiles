require 'time'

class Task
  attr_reader :name
  
  def initialize(name, start)
    if start.is_a? String
      in_time = Time::parse(start)
    elsif start.is_a? Time
      in_time = start
    end
    @name = name
    @occurences = [[in_time]]
  end
  
  def time
    seconds = 0.0
    @occurences.each do |interval|
      seconds += (interval.last - interval.first) unless interval.size == 1
    end
    seconds
  end

  def clocked_in?
    @occurences.last.size == 1
  end

  def clocked_out?
    @occurences.last.size == 2
  end
  
  def clock_in(time)
    raise ArgumentError, "you are not clocked out of #{@name}" if clocked_in?
    in_time = Time::parse(time)
    @occurences.push([in_time])     # a new start-end time pair
  end

  def clock_out(time)
    raise ArgumentError, "you are not clocked into #{@name}" if clocked_out?
    out_time = Time::parse(time)
    @occurences.last.push out_time
  end

  def num_occurences
    @occurences.size
  end

  def to_s
    "{@name}: (#{@occurences.size}x) => #{self.time}"
  end
  
end
