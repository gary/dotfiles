#!/usr/bin/perl
use strict;

# first release:
# minor name changes
# reformatting-per-protocol extracted to a sub.
# regexen for hostname/filename matching... enables playing nicely with
# both STDIN and file input.

while (<>) {
  chomp;
  print "STDIN: $_\n";
}

print "done with first round, print again?\n";


while (<>) {
  chomp;
  print "STDIN: $_\n";
}
