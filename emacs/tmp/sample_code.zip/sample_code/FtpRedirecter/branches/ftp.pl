#!/usr/bin/env perl
#*******************************************************************************
# FILENAME: ftp.pl
#
# USAGE:
#   ftp.pl [-vn] < batch_file
#
#   ftp.pl [-vn] hostname <<EOF1
#   commands
#   EOF1
#
# DESCRIPTION:
#   This Perl script will redirect FTP transactions through a secure protocol--
#   either SSH or FTPS--on a per-host basis.  How a host is handled depends on
#   how it is setup in the script's configuration file, ftp.conf.  By default,
#   this file is expected to be in the same directory as the script, but this can
#   be changed via $CONF.
#
#   Seamless redirection can be acheived by renaming this script to 'ftp' and
#   placing it and disabling the ftp binary.
#
# CONFIGURATION FILE FORMAT:
#   This script's configuration file must contain entries with the following
#   fields, separated by whitespace:
#
#   hostname - The hostname to match on.
#   remote user - The user name to login to the hostname with.
#   local user - The local user name, included for reason's beyond my control.
#   protocol - An alternate, preferably more secure, protocol to FTP.
#
#   The last line of the file should have the hostname, remote user, and local
#   user values set to "*" to ensure that all unmatched hostnames use a
#   default protocol.
#
# INPUTS:
#   -v - Verbose logging for all steps and programs in the process.
#   -n - legacy flag passed in by supported FTP commands.  Ignored.
#   batch_file - a file containing the FTP commands for a transaction.
#   commands - raw FTP commands sent through STDIN.
#
# OUTPUTS:
#   Whatever the alternate program writes to STDOUT, or that and more if the -v
#   flag is used.
#
#*******************************************************************************
require FTP::Redirecter;
require Getopt::Std;
use strict;

my $CONF = "ftp.conf";

Getopt::Std::getopts("vn");
my $VERBOSE = (defined $Getopt::Std::opt_v) ? 'v' : '';

exit if !@ARGV;

# sub make_curled($@%);
# sub stdin_args($@$);
# sub rfc959($);

my $origcmd = 'ftp ' . join(' ', @ARGV);
# get login credentials, save the transacti4on
# TODO: assuming one transaction per batchfile?
my %creds;
# check in arguments first
while ($_ = shift @ARGV) {
  if (/^[a-zA-Z0-9\-\.]+\.(edu|com|net|org|mil|EDU|COM|NET|ORG|MIL)$/) {
    $creds{hostname} = "$_";
  } elsif (/^([a-zA-Z0-9_-]+)\.txt$/) {
    # if we find a file, push it back to STDIN so we can record the comamnds from it
    unshift @ARGV, $_;
    last;
  }
  # else, STDIN
}

my @ftp_cmds;
while (<>) {
  chomp;
  print "STDIN: $_\n" if $VERBOSE;
  if (/^open\s+(.+|[^ ])/) {
    $creds{hostname} = "$1";
  } elsif (/^user\s+(\w+)\s+([^ ]+)/) {
    $creds{passwd} = $2;
  }
  push(@ftp_cmds, $_);
}

# match credentials with the redirect protocol
print "searching $CONF for $creds{hostname}..." if $VERBOSE;
open(CONF, $CONF) or die "error opening $CONF: $!\n";
while (<CONF>) {
  next if (/^\w*#/);

  chomp;
  my($cur_host, $ruser, $luser, $protocol) = split(/\s+/);
  if ($cur_host eq $creds{hostname}) {
    $creds{luser} = $luser;
    $creds{ruser} = $ruser;
    $creds{protocol} = lc $protocol;
    print "found.\n" if $VERBOSE;
    last;
  } elsif ($cur_host eq '*') {
    print "$creds{hostname} not found, defaulting to $protocol." if $VERBOSE;
    $creds{protocol} = $protocol; # last
  }
} continue {
  print '.' if $VERBOSE;
}
close(CONF);

# reformat the transaction for the new protocol
my $redirect;
if ($creds{protocol} ne 'ftp') {
  my @refmt_cmds;

  my %sftp_disabled = (open => undef, user => undef, close => undef, passive => undef);
  my %ftps_disabled = (open => undef, user => undef, passive => undef);

  # remove unsupported ftp commands
  print "reformatting commands for $creds{protocol}...\n" if $VERBOSE;
  if ($creds{protocol} eq 'sftp') {
    foreach (@ftp_cmds) {
      /(\w+)(\s+(\S+))?/;
      push (@refmt_cmds, $_) unless exists $sftp_disabled{$1};
    }
    $redirect =
      FTP::Redirector::make_stdin("sftp -${VERBOSE} $creds{ruser}" .
                 '@' . $creds{hostname}, \@refmt_cmds);
  } elsif ($creds{protocol} eq 'ftps') {
    my $curlopts =
      "-${VERBOSE}u $creds{ruser}:$creds{passwd} " .
        '--cacert --ftp-ssl-reqd';

    $redirect =
      FTP::Redirecter::make_curled("curl $curlopts", \@ftp_cmds, \%ftps_disabled);
  }
} else {
  $redirect = FTP::Redirecter::make_stdin($origcmd, \@ftp_cmds);
}

system($redirect);
