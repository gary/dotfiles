package FTP::Redirecter;

use strict;

our %disabled;

$disabled{sftp} = (open => undef, user => undef, close => undef, passive => undef);
$disabled{ftps} = (open => undef, user => undef, passive => undef);

#*******************************************************************************
# make_curled
#   create a cURL command from a series of ftp commands.  this is complicated
#   by a) cURL's -Q option (quote raw, RFC959-style ftp commands), and b) the
#   'lcd' command supported, which is not RFC959 compliant.  given the obstacles,
#   a 'cURL command', in some cases, becomes a chain of cURL and shell commands
#   that facilitate a mid-transaction local directory change.
#
# PARAMETERS:
#   $basecmd - cURL command to append the FTP commands to.
#   \@ftp_cmds - a reference to an array of FTP commands.
#   \%disabled - hash ref of disabled commands for the protocol cURL is using.
#
# RETURNS:
#   a cURL command with each RFC959 compliant FTP command appended if there
#   was no 'lcd' command issued in the \@ftp_cmds, or a sequence of cURL and
#   cd commands if so.
#
# EXAMPLE OUTPUT:
#   non-lcd transaction:
#   curl -u user:passwd --ftp-ssl-reqd --url ftp://foo.com -Q "CWD dir"
#   -Q "STOR bar.txt" -Q "QUIT"
#
#   with lcd:
#   curl -u user:passwd --ftp-ssl-reqd --url ftp://foo.com -Q "CWD dir"
#   -Q "STOR bar.txt" -Q "QUIT" && \
#   cd ldir && \
#   curl -u user:passwd --ftp-ssl-reqd --url ftp://foo.com -Q "CWD dir"
#   -Q "CWD dir2" -Q "STOR baz.pl" -Q "QUIT"
#*******************************************************************************
sub FTP::Redirecter::make_curled {
  my $curlbase = $_[0];
  my $ldir;
  my $rdir;

  my @curlchain;
  my $args;
  # all commands, unioned
  sub curl_cmd {
    return (scalar @curlchain > 1) ? join("; ", @curlchain) : "@curlchain";
  }
  sub last_curl { return @curlchain[scalar @curlchain - 1]; }
  # add a command to the curl command chain
  sub new_curl { push(@curlchain, $_[0]); }
  # append an argument to the current curl command (last in chain)
  sub add_arg { $curlchain[scalar @curlchain - 1] .= $_[0]; }

  sub next_curl {
    my $transfer = $_[0];
    my @files = $_[1];
    if ($transfer eq 'put') {
      while ($_ = shift @files) {
        # add_arg(" -O %creds{hostname}:21/$_");
        $args .= " -O %creds{hostname}:21/$_";
      }
      new_curl("$curlbase --url %creds{hostname}:21" .
               ($rdir ne '') ? " -Q \"+CWD $rdir\"" : '');
    } elsif ($transfer eq 'get') {
      # finish the last, file uploading curl call
      # add_arg(' -T "{' . join(',', @files) . '}"');
      $args .= ' -T "{' . join(',', @files) . '}"';
      @files = ();
      # start the next curl commmand for file downloading, as that's what
      # brought us here
      new_curl("$curlbase " . ($rdir ne '') ? " -Q \"+CWD $rdir\"" : '');
    } else {
      die "unknown transfer type: $transfer";
    }
  }

  # curl expects uploaded files the form of "{file1,file2,file3..}"
  my %files = (get => [], put => []);

  my @ftp_cmds = @{@_[1]};
  my $disabled = $_[2];
  foreach (@ftp_cmds) {
    if ((my $cmd, my $ws, my $params) = /(\w+)(\s+(\S+))?/) {
      # handle special case behavior
      if ($cmd eq 'lcd') {
        # track the local directory for mutliple uploads, which must
        # be the form of "{file1,file2,dir/file3}"
        $ldir = $params;
      } elsif ($cmd eq 'cd') {
        # track the remote directory for cases when we cd, upload, and
        # then cd somewhere else etc.
        if ($rdir) {
          $rdir .= "/$params";
        } else {
          $rdir = $params;
        }
      } elsif ($cmd eq 'put') {
        #next_curl($cmd, \$files{put}) if (scalar @{$files{get}});
        push(@{$files{put}}, (($ldir ne '') ? "$ldir/" : '') . $params);
      } elsif ($cmd eq 'get') {
        #next_curl($cmd, \$files{get}) if (scalar @{$files{put}});
        push(@{$files{get}}, $params);
      }

      if ((my $rfccmd = rfc959($cmd)) && !(exists $disabled->{$cmd})) {
        my $last_curl = last_curl();
        if (!$last_curl) {
          # add new curl command if previous command was a non-curl command
          new_curl("$curlbase");
          $args .= " -Q \"$rfccmd" . ((($params) ? " $params" : '' ) . '"');
        # } elsif ($rfccmd =~ /CWD/ && $last_curl =~ /CWD/ &&
#                  $last_curl !~ /-(T|O)/) {
#           # we can't change directories after we have files to transfer: finish
#           # this command and start a new, accounting for the directory change
#           my $transfer = ($1 eq 'T') ? 'put' : 'get';
#           next_curl($transfer, \$files{$transfer});
        } else {
          # append the next, quoted FTP command to the current curl command
          # add_arg(" -Q \"$rfccmd" . (($params) ? " $params" : '' ) . '"');
          $args .= " -Q \"$rfccmd" . (($params) ? " $params" : '' ) . '"';
        }
      }
    }
  }

  # wow, this is ugly
  my $curl_cmd = $curlbase;
  if (scalar @{$files{get}}) {
    while ($_ = shift @{$files{put}}) {
      # add_arg(" -O %creds{hostname}:21/$_");
      $curl_cmd .= " -O %creds{hostname}:21/$_";
    }
  } else {
    $args = " --url ftp://$creds{hostname}:21 $args";
    $curl_cmd .= $args . ' -T "{' . join(',', @{$files{put}}) . '}"';
  }
  #return curl_cmd();
  return $curl_cmd;
}


#*******************************************************************************
# make_stdin
#   append commands from an array to a command string in unix-style fashion.
#   and i do mean fashion.
#
# PARAMETERS:
#   $cmd - the command/options that will have the arguments appended to it
#   \@args: reference to the array of  args to be appended to the command
#   $eof: the end of file identifier.  defaults to EOF1.
#
# RETURNS:
#   a string representing the command taking the arguments from stdin,
#   complete with newlines.
#
# EXAMPLE OUTPUT:
#   ftp -n << EOF1
#   open somehost
#   user password
#   put file
#   bye
#   EOF1
#*******************************************************************************
sub FTP::Redirecter::make_stdin {
  my $cmd = $_[0];
  my @args = @{@_[1]};
  my $eof = ($_[2] eq '') ? 'EOF1' : $_[2];

  my $cmd_stdin = "$cmd << $eof\n";
  foreach (@args) {
    $cmd_stdin .= "$_\n";
  }
  $cmd_stdin .= "$eof";
  return $cmd_stdin;
}


#*******************************************************************************
# rfc959
# convert FTP commands into RFC959 compliant form.
#
# PARAMETERS:
# $cmd - the FTP command name to be converted
#
# RETURNS:
# the RFC959 compliant form of the FTP command name if it exists, or '' if it
# does not.
#*******************************************************************************
sub rfc959 {
  $_ = $_[0];
  my $rfccmd;
 SWITCH: {
    if (/^open/) { $rfccmd = 'OPEN'; last SWITCH; }
    if (/^user/) { $rfccmd = 'USER'; last SWITCH; }
    # prevent curl from attempting to cd to the same directory for
    # each file in a batch upload (-T "{file,file2}") by forcing the
    # CWD command to be sent right before any transfer commands
    # (instead of at the start of a transaction)
    if (/^cd/) { $rfccmd = '+CWD'; last SWITCH; }
    # if (/^put/) { $rfccmd = 'STOR'; last SWITCH; } curl -T
    # if (/^get/) { $rfccmd = 'RETR'; last SWITCH; } curl -O
    if (/^passive$/) { $rfccmd = 'PASV' ; last SWITCH; }
    # if (/^(quit|bye|close)$/) { $rfccmd = 'QUIT'; last SWITCH; } #
    # TODO
    $rfccmd = ''; # stop if we hit an unsupported command
  }
  print "$_ => " . (($rfccmd ne '') ? $rfccmd : 'not found') . "\n" if $VERBOSE;
  return $rfccmd;
}

1;
