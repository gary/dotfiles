#!/usr/bin/perl -w

use strict;

foreach (0..20) {
  my $line = "hello gary";
  print "$_ : $line";
}
