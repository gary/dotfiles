#!/usr/bin/env perl
#*******************************************************************************
# FILENAME: ftp.pl
#
# USAGE:
#   ftp.pl [-vnT] < batch_file
#
#   ftp.pl [-vnT] hostname <<EOF1
#   commands
#   EOF1
#
# DESCRIPTION:
#   This Perl script will redirect FTP transactions through a secure protocol--
#   either SSH or FTPS--on a per-host, per-user basis.  How a host is handled
#   depends on how it is setup in the script's configuration file, ftp.conf.
#   By default, this file is expected to be in /usr/local/etc, but this behavior
#   can be overridden by setting the CONF environment variable to a different
#   path.
#
#   Seamless redirection can be acheived by renaming this script to 'ftp' and
#   placing it before the ftp binary in the system's PATH.
#
# CONFIGURATION FILE FORMAT:
#   This script's configuration file must contain entries with the following
#   fields, separated by whitespace:
#
#   hostname - The hostname to match on.
#   remote user - The user name to login to the hostname with.  It must either
#   match on the user name in the transaction or be specified as '*' (which
#   will default to the user name in the original FTP transaction).
#   local user - the name of the user executing the script.  If specified as
#   '*', this value will default to the current user name (excepting root).
#   protocol - An alternate, preferably more secure, protocol to FTP.
#
#   The last line of the file should have the hostname, remote user, and local
#   user values set to "*" to ensure that all unmatched hostnames use a default
#   protocol.
#
# INPUTS:
#   -v - Verbose logging for all steps and programs in the process.
#   -n - legacy flag passed in by supported FTP commands.  Ignored.
#   -T - test mode: run in-code tests and display redirection output.
#   batch_file - a file containing the FTP commands for a transaction.
#   commands - FTP commands sent via STDIN.
#
# OUTPUTS:
#   Whatever the alternate program writes to STDOUT, or that and more if the -v
#   flag is used.
#
#*******************************************************************************
require Getopt::Std;
use strict; no strict 'subs';
use Env qw{CONF};
use File::Spec;
use Test::More tests => 5, import =>['!fail'];
use constant DISABLED => -1;
use constant ALLOWED => 1;

exit if !@ARGV;

my $origcmd = '/usr/bin/ftp ' . join(' ', @ARGV);

Getopt::Std::getopts("vT");
my $VERBOSE = (defined $Getopt::Std::opt_v) ? 'v' : '';
my $TEST = (defined $Getopt::Std::opt_T) ? 'T' :'';

# sub make_curled($@%);
# sub stdin_args($@$);
# sub rfc959($);

# get login credentials, save the transaction
my %creds;
while ($_ = shift @ARGV) {
  if (/^[a-zA-Z0-9\-\.]+\.(edu|com|net|org|mil|EDU|COM|NET|ORG|MIL)$/) {
    $creds{hostname} = $_;
    last;
  }
}
my @ftp_cmds;
while (<>) {
  chomp;
  print "STDIN: $_\n" if $VERBOSE;
  if (/^open\s+(.+|[^ ])/) {
    $creds{hostname} = "$1";
  } elsif (/^user\s+(\w+)\s+([^ ]+)/) {
    $creds{user} = $1;
    $creds{passwd} = $2;
  }
  push(@ftp_cmds, $_);
}

my $hosts = ($CONF =~ /ftp\.conf$/) ? $CONF : '/usr/local/etc/ftp.conf';
ok(-r $hosts, 'readable host file') if $TEST;

chomp(my $cuser = `whoami`);

print "searching $hosts for $creds{hostname}" if $VERBOSE;
my @host_creds;
open(HOSTS, $hosts) or die "error opening $hosts: $!\n";
while (<HOSTS>) {
  next if (/^\w*#/);

  chomp;
  my($cur_host, $ruser, $luser, $protocol) = split(/\s+/);
  # match on hostname and the user running the script ('*' ignores this)
  if ($creds{hostname} eq $cur_host && ($luser eq '*' || $cuser eq $luser)) {
    print "...found.\n" if $VERBOSE;
    if ($ruser eq '*' || $ruser eq $creds{user}) {
      chomp($cuser = `whoami`);

      # remote users matched per-name or by * (username in ftp transaction)
      $creds{ruser} = ($ruser ne 'root') ? $creds{user} : 'guest';
      if ($luser eq '*') {
        $creds{luser} = $cuser;
      } elsif ($luser eq 'root') {
        $creds{$luser} = 'not-root';
      } else {
        $creds{luser} = $luser;
      }
      $creds{protocol} = lc $protocol;
      last;
    }
  } elsif ($cur_host eq '*') {
    print "not found, defaulting to $protocol.\n" if $VERBOSE;
    $creds{protocol} = $protocol;
  }
} continue {
  print '.' if $VERBOSE;
}
close(CONF);

# reformat the transaction for the new protocol
my @redirect;
if ($creds{protocol} ne 'ftp') {
  my @refmt_cmds;

  # remove unsupported ftp commands
  print "reformatting commands for $creds{protocol}...\n" if $VERBOSE;
  if ($creds{protocol} eq 'sftp') {
    my %sftp_rules = (binary => DISABLED,
                      bye => DISABLED,
                      cd => ALLOWED,
                      close => DISABLED,
                      dir => ALLOWED,
                      get => ALLOWED,
                      lcd => ALLOWED,
                      mget => ALLOWED,
                      mput => ALLOWED,
                      open => DISABLED,
                      passive => DISABLED,
                      put => ALLOWED,
                      pwd => ALLOWED,
                      rename => ALLOWED,
                      user => DISABLED,
                     );
    foreach (@ftp_cmds) {
      /(\w+)(\s+(\S+))?/;
      if ($sftp_rules{$1} == ALLOWED) {
        push @refmt_cmds, $_;
      } elsif ($sftp_rules{$1} == DISABLED) {
        print "disabled command: $1\n" if $VERBOSE;
      } else {
        die "unsupported command: $1\n";
      }
    }

    my $sftp = 'sftp ';
    $sftp .= '-v' if $VERBOSE;
    $sftp .= " $creds{ruser}" . '@' . $creds{hostname};
    @redirect = make_stdin($sftp, \@refmt_cmds);
  } elsif ($creds{protocol} eq 'ftps') {
     my %ftps_rules = (binary => DISABLED,
                       bye => DISABLED,
                       cd => ALLOWED,
                       close => DISABLED,
                       dir => DISABLED,
                       get => ALLOWED,
                       lcd => ALLOWED,
                       mget => ALLOWED,
                       mput => ALLOWED,
                       open => DISABLED,
                       passive => DISABLED,
                       put => ALLOWED,
                       pwd => DISABLED,
                       user => DISABLED,
                      );
    my $curlopts =
      "-${VERBOSE}u $creds{ruser}:$creds{passwd} " .
        '--cacert --ftp-ssl-reqd';
     if ($TEST) {
       # are the parameteres of allowed command preserved?
       my @allowed_cmd = make_curled("curl $curlopts",
                                     ['cd somewhere', 'put a_file'],
                                     \%ftps_rules);
       like(@allowed_cmd[0], qr/somewhere.*a_file/,
          'curl ALLOWED command');

       # are disabled commands thrown out?
       my @disabled_cmd = make_curled("curl $curlopts",
                                      ['cd somewhere', 'binary', 'put a_pdf'],
                                      \%ftps_rules);
       unlike(@disabled_cmd[0], qr/binary/, 'curl DISABLED command');

     SKIP: {
         eval { ok(make_curled("curl $curlopts", ['rename'], \%ftps_rules),
                   'curl an unsupported command.') };
         skip "curl unsupported command blows up script", 1 if $@;
       }
     }
    @redirect = make_curled("curl $curlopts", \@ftp_cmds, \%ftps_rules);
  }
} else {
  # input style preservation
  @redirect = ($origcmd =~ /</) ? $origcmd : make_stdin($origcmd, \@ftp_cmds);
}

foreach (@redirect) {
  ($TEST) ? print "$_\n" : system($_);
}


#******************************************************************************
# make_curled
#   create a cURL command from a series of ftp commands.
#
# PARAMETERS:
#   $basecmd - cURL command to append the FTP commands to.
#   \@ftp_cmds - a reference to an array of FTP commands.
#   \%rules - hash ref of rules for the ftp commands that cURL is using.
#
# RETURNS:
#   depending on the complexity of the transaction in @ftp_cmds, the following
#   can be returned:
#
#   > a single, cURL command.  this will be the case for transactions that
#     change the remote directory 1+ times before {up,down}loading files.
#
#   > multiple cURL commands.  this becomes necessary if there are remote
#     directory changes in the middle of {up,down}loading files.  it is also
#     necessary when a transaction uploads and downloads files, as cURL can
#     only do one type of file transfer at a time.  see the 'EXAMPLE OUTPUT'
#     section in the add_a_curl private function's documentation for more info.
#
#******************************************************************************
sub make_curled {
  my @curl_cmds;

  #****************************************************************************
  # add_a_curl
  #
  # build a properly formatted cURL command and return it for addition to the
  # list of cURL commands for accomplishing an FTP transaction.
  #
  # PARAMETERS:
  #   $curl_cmd - the cURL command and any accompanying flags/options
  #   $args - options that resulted from transforming the FTP transaction
  #   %files - the files to transfer, both GET and PUT
  #
  #
  # RETURNS:
  #   a cURL command with the appropriate options and format for the files to be
  #   {up,down}loaded.  see the example output to better understand what it all
  #   means.
  #
  # EXAMPLE OUTPUT:
  #   get transaction:
  #   curl -u user:passwd --ftp-ssl-reqd -Q "+CWD dir" -O ftp://foo.com:21/file1
  #
  #   put transaction, no lcd:
  #   curl -u user:passwd --ftp-ssl-reqd --url ftp://foo.com:21 -T "{file1,file2}"
  #
  #   put transaction, lcd:
  #   curl -u user:passwd --ftp-ssl-reqd --url ftp://foo.com:21 -Q "+CWD dir"
  #   -T "{file1,dir/file2}"
  #******************************************************************************
  my $add_a_curl = sub {
    my $curl_cmd = $_[0];
    my $args = $_[1];
    my %files = %{@_[2]};

    if (scalar @{$files{get}}) {
      $curl_cmd .= $args;
      foreach my $file (@{$files{get}}) {
        $curl_cmd .= " -O ftp://$creds{hostname}:21/$file";
      }
    } else {
      $args = " --url ftp://$creds{hostname}:21 $args";
      $curl_cmd .= $args . ' -T "{' . join(',', @{$files{put}}) . '}"';
    }
    return $curl_cmd;
  };

  # arguments differ for each transfer type
  my $args;
  # each transfer type has a different format.  as this is not known ahead of
  # time, save all files and evaluate at the end.
  my %files = (get => [], put => []);

  my $ldir;
  my $rdir;

  my @ftp_cmds = @{@_[1]};
  my $rules = $_[2];
  # evaluate each raw ftp command
  foreach (@ftp_cmds) {
    if ((my $cmd, my $params) = /(\w+)(?:\s+(.*))?/) {
      my $num_getfiles = scalar @{$files{get}};
      my $num_putfiles = scalar @{$files{put}};
      # handle special case behavior
      if ($cmd eq 'lcd') {
        # track the local directory for uploads
        $ldir = File::Spec->catdir('.', $ldir, $params);
      } elsif ($cmd eq 'cd') {
        if ($rdir ne '') {
          print "directory change with files to transfer: new curl command.\n"
            if $VERBOSE;
          ok(($num_getfiles == 0) || ($num_putfiles == 0),
             'only one file group to transfer?') if $TEST;
          push @curl_cmds, &$add_a_curl(@_[0], $args, \%files);
          $files{get} = [];     # both arrays should never have files in them
          $files{put} = [];     # at the same time
        }
        $rdir = File::Spec->catdir($rdir, $params);
      } elsif ($cmd =~ /m?put/) {
        # if get has entries and this is our first, finish and restart
        if ($num_getfiles && !$num_putfiles) {
          print "adding new curl command with $num_putfiles files to get...\n"
            if $VERBOSE;
          push @curl_cmds, &$add_a_curl($_[0], $args, \%files);
          $files{get} = [];
        }
        my $file = ($ldir ne '') ?
          File::Spec->catfile($ldir, $params) : $params;
        push(@{$files{put}}, $file);
      } elsif ($cmd =~ /m?get/) {
        # if put has entries and this is our first, finish and restart
        if ($num_putfiles && !$num_getfiles) {
          print "adding new curl command with $num_putfiles files to put...\n"
            if $VERBOSE;
          push @curl_cmds, &$add_a_curl($_[0], $args, \%files);
          $files{put} = [];
        }
        push(@{$files{get}}, $params);
      }
      # append the next, quoted FTP command to the arguments
      my $rfccmd;
      if ($rules->{$cmd} == ALLOWED) {
        $args .= " -Q \"$rfccmd" . (($params) ? " $params" : '' ) . '"'
          if ($rfccmd = rfc959($cmd));
      } elsif ($rules->{$cmd} == DISABLED) {
        print "disabled command: $cmd\n" if $VERBOSE;
      } else {
        die "unsupported command: $cmd\n";
      }
    }
  }

  push @curl_cmds, &$add_a_curl($_[0], $args, \%files);
  return @curl_cmds;
}


#******************************************************************************
# make_stdin
#   create a unix-style, STDIN call to a command given arguments and,
#   optionally, an end of file chracter sequence.
#
# PARAMETERS:
#   $cmd - the command/options that will have the arguments appended to it
#   \@args: reference to the array of  args to be appended to the command
#   $eof: the end of file identifier.  defaults to EOF1.
#
# RETURNS:
#   a string representing the command taking the arguments from STDIN,
#   complete with newlines.
#
# EXAMPLE OUTPUT:
#   ftp -n << EOF1
#   open somehost
#   user password
#   put file
#   bye
#   EOF1
#******************************************************************************
sub make_stdin {
  my $cmd = $_[0];
  my @args = @{@_[1]};
  my $eof = ($_[2] eq '') ? 'EOF1' : $_[2];

  my $cmd_stdin = "$cmd << $eof\n";
  foreach (@args) {
    $cmd_stdin .= "$_\n";
  }
  $cmd_stdin .= "$eof";
  return $cmd_stdin;
}


#*******************************************************************************
# rfc959
# convert FTP commands into RFC959 compliant form.
#
# PARAMETERS:
# $cmd - the FTP command name to be converted
#
# RETURNS:
# the RFC959 compliant form of the FTP command name if it exists, or '' if it
# does not.
#*******************************************************************************
sub rfc959 {
  $_ = $_[0];
  my $rfccmd;
 SWITCH: {
    if (/^open/) { $rfccmd = 'OPEN'; last SWITCH; }
    if (/^user/) { $rfccmd = 'USER'; last SWITCH; }
    # prevent curl from attempting to cd to the same directory for
    # each file in a batch upload (-T "{file,file2}") by forcing the
    # CWD command to be sent right before any transfer commands
    # (instead of at the start of a transaction)
    if (/^cd/) { $rfccmd = '+CWD'; last SWITCH; }
    # if (/^put/) { $rfccmd = 'STOR'; last SWITCH; } curl -T
    # if (/^get/) { $rfccmd = 'RETR'; last SWITCH; } curl -O
    if (/^passive$/) { $rfccmd = 'PASV' ; last SWITCH; }
    # QUIT sent automatically by curl
    # if (/^(quit|bye|close)$/) { $rfccmd = 'QUIT'; last SWITCH; }
    $rfccmd = ''; # stop if we hit an unsupported command
  }
  print "$_ => $rfccmd\n" if ($VERBOSE && $rfccmd ne '') ;
  return $rfccmd;
}
