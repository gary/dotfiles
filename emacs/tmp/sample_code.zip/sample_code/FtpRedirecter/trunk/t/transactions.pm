package Transactions;

use strict;

#******************************************************************************
# transactions:
# - simple get
our $simple_get;
# - simple put
our $simple_put;
# - multiple directory changes
our $multi_cd;
# - complex: utilizing all of the above
our $complex;

$simple_get =<<"EOD";
cd directory
get some_file
get another_file
bye
EOD

$simple_put =<<"EOD";
cd directory
put some_file
put another_fle
bye
EOD

$multi_cd =<<"EOD";
cd directory
put some_file
put another_file
cd subdirectory
put that_file
bye
EOD

$complex =<<"EOD";
cd directory
put some_file
put another_file
cd subdirectory
get that_file
bye
EOD

1;
