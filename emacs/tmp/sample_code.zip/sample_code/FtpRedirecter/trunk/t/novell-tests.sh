#!/bin/sh

export CONF="/Users/giams/mprojs/FtpRedirecter/trunk/ftp.conf"
REDIRECTOR="../ftp.pl"
ARGS="-nT"

for test in `ls *.txt`
do
    echo $test | cut -c 6- | tr "_" " "
    echo "-- transaction:"
    cat $test
    echo "-- redirect:"
    $REDIRECTOR $ARGS < $test
    echo
done
