#!/usr/bin/env perl
use strict;
use warnings;
# use Test::More tests => 1;
use Env qw{REDIRECTER};

my $REDIRECTER_CALL = "$REDIRECTER -nT ";

# v is for valid
# i is for invalid
# m is for murder
my $v_host = 'mulnx22.mcs.muohio.edu';
my $i_host = 'bogus.mcs.muohio.edu';

my $v_ruser = 'bbuser';
my $i_ruser = 'barney';

my $n_flag_bitching = "Unknown option: n\n";

# sub get_expected_result($);

use Transactions;
my $good_get_call = "$REDIRECTER_CALL $v_host <<EOF1
$v_ruser password
$Transactions::simple_get
EOF1";

# chomp(my $result = `$good_get_call`);
# ok($result == get_expected_result($v_ruser, $v_host, $Transactions::simple_get),
#   'simple GET transaction');


# sub get_expected_result {
#   my $ruser = $_[0];
#   my $host = $_[1];
#   my $trans = $_[2];

#   my %sftp_disabled = (open => undef, user => undef, close => undef,
#                        passive => undef);

#   my @orig_trans = split /\n/, $trans;
#   my @new_trans = ();
#   foreach (@orig_trans) {
#     /(\w+)(\s+(\S+))?/;
#     push (@new_trans, $_) unless exists $sftp_disabled{$1};
#   }

#   my $scrubbed_trans = join("\n", @new_trans);
#   return "sftp - $ruser@$host <<EOF1
# $scrubbed_trans
# EOF1";
# }
