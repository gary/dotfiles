require File.dirname(__FILE__) + '/../test_helper'

class BrokerageAccountTest < ActiveSupport::TestCase

  def test_balance_summation    # making sure i rememeber inject
#     test_account = create_test_brokerage_account

#     manual_summation = 0
#     test_account.stocks.map { |s| s.current_value }
    
    #     assert test_account.stock_balance, manual_summation
    true
  end

  private
  def create_test_brokerage_account
    b = BrokerageAccount.create(:name => 'ETrade')
    b.stocks.create!(:symbol => 'GOOG', :quantity => 50)
    b.stocks.create!(:symbol => 'AAPL', :quantity => 100)
    b.stocks.create!(:symbol => 'JPM', :quantity => 5)
    b.stocks.create!(:symbol => 'ECSPQ', :quantity => 50000) # sucker!
    b.stocks.create!(:symbol => 'YUMM', :quantity => 15)
    return b
  end

end
