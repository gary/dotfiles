require File.dirname(__FILE__) + '/../test_helper'

class AccountTest < ActiveSupport::TestCase

  def test_create_account_known_good_params
    a = Account.factory('Account', Account.valid_options)
    assert_kind_of Account, a
  end

  def test_create_savings_account_good_params
    s = Account.factory('SavingsAccount', SavingsAccount.valid_options)
    assert_kind_of SavingsAccount, s
  end

  def test_create_checking_account_good_params
    c = Account.factory('CheckingAccount', CheckingAccount.valid_options)
    assert_kind_of CheckingAccount, c
  end

  def test_create_brokerage_account_good_params
    b = Account.factory('BrokerageAccount', BrokerageAccount.valid_options)
    assert_kind_of BrokerageAccount, b
  end

  def test_unspecified_type_should_default_to_account
    unknown = Account.factory(nil, nil)
    assert_kind_of Account, unknown
  end
end
