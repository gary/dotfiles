class CreateTransactions < ActiveRecord::Migration
  def self.up
    create_table :transactions do |t|
      t.integer :account_id, :references => :accounts
      t.string :title, :category 
      t.decimal :amount, :precision => 6, :scale => 2
      t.timestamps
    end
  end

  def self.down
    drop_table :transactions
  end
end
