class CreateStocks < ActiveRecord::Migration
  def self.up
    create_table :stocks do |t|
      t.integer :brokerage_account_id, :references => :accounts
      t.string :symbol
      t.integer :quantity
    end
  end

  def self.down
    drop_table :stocks
  end
end
