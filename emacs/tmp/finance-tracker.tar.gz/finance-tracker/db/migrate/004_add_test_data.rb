class AddTestData < ActiveRecord::Migration
  CATEGORIES = ['Misc', 'Entertainment', 'Maintenance', 'Airfare',
                'Food', 'Bills']
  def self.up
    Account.delete_all
    s = SavingsAccount.create(:name => 'The account no one wanted',
                              :balance => 5000.75)
    s.transactions.create!(:title => 'Employer A direct deposit',
                           :category => CATEGORIES[0],
                           :amount => 100.00)
    s.transactions.create!(:title => 'Dirty Money',
                           :category => CATEGORIES[0],
                           :amount => 100.00)
    s.transactions.create!(:title => 'Electric Bill',
                           :category => CATEGORIES[5],
                           :amount => -70.00)
    s.transactions.create!(:title => 'Daddy needs a used car',
                           :category => CATEGORIES[2],
                           :amount => -4000.00)

    s2 = SavingsAccount.create(:name => 'Money market account',
                               :balance => 160_745_450.50)
    s2.transactions.create!(:title => 'Employer B direct deposit',
                            :category => CATEGORIES[0],
                            :amount => 10000.00)
    s2.transactions.create!(:title => 'Dirty Money',
                            :category => CATEGORIES[0],
                            :amount => 100.00)
    s2.transactions.create!(:title => 'Electric Bill',
                            :category => CATEGORIES[5],
                            :amount => -7000.00)
    s2.transactions.create!(:title => 'Daddy needs murcielago',
                            :category => CATEGORIES[2],
                            :amount => -300_000.00)

    c = CheckingAccount.create(:name => 'No fee checking',
                               :balance => 200.00)
    c.transactions.create!(:title => 'Big Boy',
                           :category => CATEGORIES[4],
                           :amount => -15.00)
    c.transactions.create!(:title => "Church's Chicken",
                           :category => CATEGORIES[4],
                           :amount => -15.00)
    c.transactions.create!(:title => 'Expensive Seafood',
                           :category => CATEGORIES[4],
                           :amount => -115.00)
    c.transactions.create!(:title => 'White Castle',
                           :category => CATEGORIES[4],
                           :amount => -20.00)
    c.transactions.create!(:title => 'Lunch Money',
                           :category => CATEGORIES[0],
                           :amount => 100.00)

    b = BrokerageAccount.create(:name => 'ETrade')
    b.stocks.create!(:symbol => 'GOOG', :quantity => 50)
    b.stocks.create!(:symbol => 'AAPL', :quantity => 100)
    b.stocks.create!(:symbol => 'JPM', :quantity => 5)
    b.stocks.create!(:symbol => 'ECSPQ', :quantity => 50000) # sucker!
    b.stocks.create!(:symbol => 'YUMM', :quantity => 15)
  end

  def self.down
    Account.delete_all
  end

end
