class CreateAccounts < ActiveRecord::Migration
  def self.up
    create_table :accounts, :force => true do |t|
      t.column :type, :string

      # common attributes
      t.column :name, :string
      t.column :balance, :decimal, :precision => 10, :scale => 2

      # attributs for type=SavingsAccount|CheckingAccount
      t.column :apy, :decimal, :precision => 5, :scale => 4
      
      t.timestamps
    end
  end

  def self.down
    drop_table :accounts
  end
end
