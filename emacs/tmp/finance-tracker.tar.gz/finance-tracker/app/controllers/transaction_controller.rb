class TransactionController < ApplicationController
  # GET /transactions/show/1
  # GET /transactions/show/1.xml
  def show
    debugger
    @transactions = Account.find(params[:id]).transactions

    respond_to do |format|
      format.html # show.html.erb
      format.xml  { render :xml => @account }
    end
  end
end
