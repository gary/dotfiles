class Account < ActiveRecord::Base
  has_many :transactions

  def self.factory(type, params = nil)
    type ||= 'Account'
    class_name = type
    params[:type] = type if !params.nil?
    class_name.constantize.new(params) # gaping security hole
  end

  def self.valid_options
    {
      :name => 'Basic Account',
      :balance => 5000.00
    }
  end
      
end
