class BrokerageAccount < Account
  has_many :stocks
  
  def stock_balance
    self.stocks.map { |s| s.current_value }.inject(0) do |bal, s|
      bal + s
    end
  end
end
