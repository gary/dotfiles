class CheckingAccount < Account
  def before_create
    self.apy = 0.009
  end

  def self.valid_options
    valid_checking_options = { :apy => 0.009 }

    # TODO: access parent class?
    Account.valid_options.merge(valid_checking_options)
  end
end
