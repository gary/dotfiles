class Stock < ActiveRecord::Base
  require 'yahoofinance'

  belongs_to :brokerage_account

  def current_value
    quote = YahooFinance::get_standard_quotes(self.symbol)
    self.quantity * quote[self.symbol].previousClose
  end

  protected
  def validate
    errors.add(:quantity, "must be at least 1") if quantity.nil? ||
      quantity < 1
  end
end
