class SavingsAccount < Account
  # TODO: APY rules
  
  protected
  def before_save
    balance = self.balance.to_f
    self.apy = if balance > 50000
                 0.0445
               elsif balance > 15000
                 0.0430
               else
                 0.0415
               end
  end
end
